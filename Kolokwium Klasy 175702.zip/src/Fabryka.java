import java.util.ArrayList;

public class Fabryka {
    private ArrayList<Elf> listaElfow;
    private double dlGeo;
    private double szGeo;

    public Fabryka(double dlGeo, double szGeo) {
        this.listaElfow = new ArrayList<>();
        if(this.dlGeo>180 && this.dlGeo < -180){
            throw new IllegalArgumentException("Wartosc musi znajdowac sie pomiedzy -180 a 180");
        }
        else{
            this.dlGeo =dlGeo;
        }
        if(this.szGeo>90 && this.szGeo < -90){
            throw new IllegalArgumentException("Wartosc musi znajdowac sie pomiedzy -90 a 90");
        }
        else{
            this.szGeo =szGeo;
        }
    }

    public void dodajPracownika(Elf elf){
        listaElfow.add(elf);
    }

    public void usunPracownika(Elf elf1){
        for(Elf elf : listaElfow){
            if(elf.equals(elf1)){
                listaElfow.remove(elf);
            }
        }
    }

    public Elf najstarszyPracownik(){
        Elf elf = listaElfow.get(0);
        int max = elf.getWiek();
        int record= 0;
        for(int i=0; i<listaElfow.size();i++){
            Elf elf1 = listaElfow.get(i);
            if(max < elf1.getWiek()){
                max = elf1.getWiek();
                record = i;
            }
        }
        return listaElfow.get(record);
    }

    public ArrayList<Elf> getListaElfow() {
        return listaElfow;
    }

    public void setListaElfow(ArrayList<Elf> listaElfow) {
        if(listaElfow.isEmpty()||listaElfow==null){
            throw new IllegalArgumentException("Lista jest pusta");
        }
        else{
            this.listaElfow=listaElfow;
        }
    }

    public double getDlGeo() {
        return dlGeo;
    }

    public void setDlGeo(double dlGeo) {
        if(this.dlGeo>180 && this.dlGeo < -180){
            throw new IllegalArgumentException("Wartosc musi znajdowac sie pomiedzy -180 a 180");
        }
        else{
            this.dlGeo =dlGeo;
        }
    }

    public double getSzGeo() {
        return szGeo;
    }

    public void setSzGeo(double szGeo) {
        if(this.szGeo>90 && this.szGeo < -90){
            throw new IllegalArgumentException("Wartosc musi znajdowac sie pomiedzy -90 a 90");
        }
        else{
            this.szGeo =szGeo;
        }
    }
}
