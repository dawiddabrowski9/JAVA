import java.util.ArrayList;
import java.util.Objects;

public class Sanie {
    private ArrayList<Renifer> listaReniferow;

    public Sanie() {
        this.listaReniferow = new ArrayList<>();
    }

    public void dodajRenifera(Renifer renifer){
        listaReniferow.add(renifer);
    }

    public void sumaPredkosci(){
        int suma = 0;
        for(int i = 0; i<listaReniferow.size();i++){
            Renifer renifer = listaReniferow.get(i);
            suma += renifer.getPredkosc();
        }
        System.out.println("Suma predkosci:" + suma);
    }

    public Renifer najwolniejszyRenifer(){
        Renifer renifer = listaReniferow.get(0);
        int min = renifer.getPredkosc();
        int record = 0;
        for(int i = 0; i<listaReniferow.size();i++){
            Renifer renifer1 = listaReniferow.get(i);
            if(min > renifer1.getPredkosc()){
                min = renifer1.getPredkosc();
                record = i;
            }
        }
        return listaReniferow.get(record);
    }

    public ArrayList<Renifer> getListaReniferow() {
        return listaReniferow;
    }

    public void setListaReniferow(ArrayList<Renifer> listaReniferow) {
        if(listaReniferow.isEmpty()||listaReniferow==null){
            throw new IllegalArgumentException("Lista jest pusta");
        }
        else{
            this.listaReniferow=listaReniferow;
        };
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Sanie sanie = (Sanie) o;
        return Objects.equals(listaReniferow, sanie.listaReniferow);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(listaReniferow);
    }

    @Override
    public String toString() {
        return "Sanie{" +
                "listaReniferow=" + listaReniferow +
                '}';
    }
}
