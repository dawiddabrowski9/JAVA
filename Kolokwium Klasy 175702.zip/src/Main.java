
public class Main {
    public static void main(String[] args) {
       Elf elf = new Elf("Dawid",22,"Inspektor powierzchni płaskich");
       Elf elf1 = new Elf("Dawid",33,"Inspektor powierzchni płaskich");
       Elf elf2 = new Elf("Dawid",29,"Inspektor powierzchni płaskich");
       elf.przedstawSie();


       Fabryka fabryka = new Fabryka(65.6,67.9);
       fabryka.dodajPracownika(elf);
       fabryka.dodajPracownika(elf1);
       fabryka.dodajPracownika(elf2);
       fabryka.usunPracownika(elf1);
       System.out.println(fabryka.najstarszyPracownik().toString());


       Renifer renifer = new Renifer("Rudolf",30);
       Renifer renifer1 = new Renifer("Rudolf1",35);
       Renifer renifer2 = new Renifer("Rudolf2",40);
       Sanie sanie = new Sanie();
       sanie.dodajRenifera(renifer);
       sanie.dodajRenifera(renifer1);
       sanie.dodajRenifera(renifer2);
       System.out.println(sanie.najwolniejszyRenifer());
       sanie.sumaPredkosci();

    }
}
